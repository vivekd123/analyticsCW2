var require = meteorInstall({"imports":{"api":{"tasks.js":["meteor/meteor","meteor/mongo","meteor/check","meteor/email",function(require,exports){

/////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                     //
// imports/api/tasks.js                                                                                //
//                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                       //
exports.__esModule = true;                                                                             //
exports.Tasks = undefined;                                                                             //
                                                                                                       //
var _meteor = require('meteor/meteor');                                                                // 1
                                                                                                       //
var _mongo = require('meteor/mongo');                                                                  // 2
                                                                                                       //
var _check = require('meteor/check');                                                                  // 3
                                                                                                       //
var _email = require('meteor/email');                                                                  // 5
                                                                                                       //
var Tasks = exports.Tasks = new _mongo.Mongo.Collection('tasks');                                      // 6
                                                                                                       //
if (_meteor.Meteor.isServer) {                                                                         // 8
  // This code only runs on the server                                                                 //
  // Only publish tasks that are public or belong to the current user                                  //
  _meteor.Meteor.publish('tasks', function () {                                                        // 11
    function tasksPublication() {                                                                      // 11
      return Tasks.find({                                                                              // 12
        $or: [{ 'private': { $ne: true } }, { owner: this.userId }]                                    // 13
      });                                                                                              //
    }                                                                                                  //
                                                                                                       //
    return tasksPublication;                                                                           //
  }());                                                                                                //
                                                                                                       //
  _meteor.Meteor.startup(function () {                                                                 // 20
    process.env.MAIL_URL = "smtp://noreply@techiepulse.com:micron123@server511.webhostingpad.com:465";
    //                                                                                                 //
    //      Email.send({                                                                               //
    //         to: "vdhutia18@gmail.com",                                                              //
    //         from: "noreply@booking.thaiembassyuk.org.uk",                                           //
    //         subject: "Royal Thai Embassy Booking Confirmation",                                     //
    //         text: "The email content..."                                                            //
    //      });                                                                                        //
    //                                                                                                 //
  });                                                                                                  // 20
                                                                                                       //
  _meteor.Meteor.methods({                                                                             // 33
    sendEmail: function () {                                                                           // 34
      function sendEmail(to, text) {                                                                   // 34
        (0, _check.check)([to, text], [String]);                                                       // 35
                                                                                                       //
        SSR.compileTemplate('htmlEmail', Assets.getText('html-email.html'));                           // 37
                                                                                                       //
        var emailData = {                                                                              // 39
          name: "Vivek",                                                                               // 40
          favoriteRestaurant: "Honker Burger",                                                         // 41
          bestFriend: "Skeeter Valentine"                                                              // 42
        };                                                                                             //
                                                                                                       //
        // Let other method calls from the same client start running,                                  //
        // without waiting for the email sending to complete.                                          //
        this.unblock();                                                                                // 34
                                                                                                       //
        _email.Email.send({                                                                            // 49
          to: "vivek.dhutia@my.westminster.ac.uk",                                                     // 50
          from: 'Techie Pulse <noreply@techiepulse.com>',                                              // 51
          subject: "Techie Pulse Week-In Review",                                                      // 52
          html: SSR.render('htmlEmail', emailData)                                                     // 53
        });                                                                                            //
      }                                                                                                //
                                                                                                       //
      return sendEmail;                                                                                //
    }(),                                                                                               //
                                                                                                       //
    sendMessage: function () {                                                                         // 57
      function sendMessage(name, email, subject, message) {                                            // 57
        // Let other method calls from the same client start running,                                  //
        // without waiting for the email sending to complete.                                          //
        this.unblock();                                                                                // 60
                                                                                                       //
        _email.Email.send({                                                                            // 62
          to: "info@techiepulse.com",                                                                  // 63
          from: email,                                                                                 // 64
          subject: subject + " - " + name,                                                             // 65
          text: message                                                                                // 66
        });                                                                                            //
      }                                                                                                //
                                                                                                       //
      return sendMessage;                                                                              //
    }()                                                                                                //
  });                                                                                                  //
}                                                                                                      //
                                                                                                       //
_meteor.Meteor.methods({                                                                               // 72
  'tasks.insert': function () {                                                                        // 73
    function tasksInsert(text) {                                                                       //
      (0, _check.check)(text, String);                                                                 // 74
                                                                                                       //
      // Make sure the user is logged in before inserting a task                                       //
      if (!this.userId) {                                                                              // 73
        throw new _meteor.Meteor.Error('not-authorized');                                              // 78
      }                                                                                                //
                                                                                                       //
      Tasks.insert({                                                                                   // 81
        text: text,                                                                                    // 82
        createdAt: new Date(),                                                                         // 83
        owner: this.userId,                                                                            // 84
        username: _meteor.Meteor.users.findOne(this.userId).username                                   // 85
      });                                                                                              //
    }                                                                                                  //
                                                                                                       //
    return tasksInsert;                                                                                //
  }(),                                                                                                 //
  'tasks.remove': function () {                                                                        // 88
    function tasksRemove(taskId) {                                                                     //
      (0, _check.check)(taskId, String);                                                               // 89
                                                                                                       //
      var task = Tasks.findOne(taskId);                                                                // 91
      if (task['private'] && task.owner !== this.userId) {                                             // 92
        // If the task is private, make sure only the owner can delete it                              //
        throw new _meteor.Meteor.Error('not-authorized');                                              // 94
      }                                                                                                //
                                                                                                       //
      Tasks.remove(taskId);                                                                            // 97
    }                                                                                                  //
                                                                                                       //
    return tasksRemove;                                                                                //
  }(),                                                                                                 //
  'tasks.setChecked': function () {                                                                    // 99
    function tasksSetChecked(taskId, setChecked) {                                                     //
      (0, _check.check)(taskId, String);                                                               // 100
      (0, _check.check)(setChecked, Boolean);                                                          // 101
                                                                                                       //
      var task = Tasks.findOne(taskId);                                                                // 103
      if (task['private'] && task.owner !== this.userId) {                                             // 104
        // If the task is private, make sure only the owner can check it off                           //
        throw new _meteor.Meteor.Error('not-authorized');                                              // 106
      }                                                                                                //
                                                                                                       //
      Tasks.update(taskId, { $set: { checked: setChecked } });                                         // 109
    }                                                                                                  //
                                                                                                       //
    return tasksSetChecked;                                                                            //
  }(),                                                                                                 //
  'tasks.setPrivate': function () {                                                                    // 111
    function tasksSetPrivate(taskId, setToPrivate) {                                                   //
      (0, _check.check)(taskId, String);                                                               // 112
      (0, _check.check)(setToPrivate, Boolean);                                                        // 113
                                                                                                       //
      var task = Tasks.findOne(taskId);                                                                // 115
                                                                                                       //
      // Make sure only the task owner can make a task private                                         //
      if (task.owner !== this.userId) {                                                                // 111
        throw new _meteor.Meteor.Error('not-authorized');                                              // 119
      }                                                                                                //
                                                                                                       //
      Tasks.update(taskId, { $set: { 'private': setToPrivate } });                                     // 122
    }                                                                                                  //
                                                                                                       //
    return tasksSetPrivate;                                                                            //
  }()                                                                                                  //
});                                                                                                    //
/////////////////////////////////////////////////////////////////////////////////////////////////////////

}]}},"server":{"main.js":["../imports/api/tasks.js",function(require){

/////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                     //
// server/main.js                                                                                      //
//                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                       //
require('../imports/api/tasks.js');                                                                    // 1
                                                                                                       //
Accounts.config({                                                                                      // 3
    forbidClientAccountCreation: true                                                                  // 4
});                                                                                                    //
/////////////////////////////////////////////////////////////////////////////////////////////////////////

}]}},{"extensions":[".js",".json",".jsx"]});
require("./server/main.js");
//# sourceMappingURL=app.js.map
