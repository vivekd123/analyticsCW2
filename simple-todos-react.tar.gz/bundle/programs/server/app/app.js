var require = meteorInstall({"imports":{"api":{"tasks.js":["meteor/meteor","meteor/mongo","meteor/check","meteor/email",function(require,exports){

/////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                     //
// imports/api/tasks.js                                                                                //
//                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                       //
exports.__esModule = true;                                                                             //
exports.Tasks = undefined;                                                                             //
                                                                                                       //
var _meteor = require('meteor/meteor');                                                                // 1
                                                                                                       //
var _mongo = require('meteor/mongo');                                                                  // 2
                                                                                                       //
var _check = require('meteor/check');                                                                  // 3
                                                                                                       //
var _email = require('meteor/email');                                                                  // 5
                                                                                                       //
var Tasks = exports.Tasks = new _mongo.Mongo.Collection('tasks');                                      // 6
                                                                                                       //
if (_meteor.Meteor.isServer) {                                                                         // 8
  // This code only runs on the server                                                                 //
  // Only publish tasks that are public or belong to the current user                                  //
  _meteor.Meteor.publish('tasks', function () {                                                        // 11
    function tasksPublication() {                                                                      // 11
      return Tasks.find({                                                                              // 12
        $or: [{ 'private': { $ne: true } }, { owner: this.userId }]                                    // 13
      });                                                                                              //
    }                                                                                                  //
                                                                                                       //
    return tasksPublication;                                                                           //
  }());                                                                                                //
                                                                                                       //
  _meteor.Meteor.startup(function () {                                                                 // 20
    process.env.MAIL_URL = "smtp://noreply@techiepulse.com:micron123@server511.webhostingpad.com:465";
    //                                                                                                 //
    //      Email.send({                                                                               //
    //         to: "vdhutia18@gmail.com",                                                              //
    //         from: "noreply@booking.thaiembassyuk.org.uk",                                           //
    //         subject: "Royal Thai Embassy Booking Confirmation",                                     //
    //         text: "The email content..."                                                            //
    //      });                                                                                        //
    //                                                                                                 //
  });                                                                                                  // 20
                                                                                                       //
  _meteor.Meteor.methods({                                                                             // 33
    sendEmail: function () {                                                                           // 34
      function sendEmail(to) {                                                                         // 34
        (0, _check.check)([to], [String]);                                                             // 35
                                                                                                       //
        SSR.compileTemplate('htmlEmail', Assets.getText('html-email.html'));                           // 37
                                                                                                       //
        var emailData = {                                                                              // 39
          name: "Vivek",                                                                               // 40
          favoriteRestaurant: "Honker Burger",                                                         // 41
          bestFriend: "Skeeter Valentine"                                                              // 42
        };                                                                                             //
                                                                                                       //
        // Let other method calls from the same client start running,                                  //
        // without waiting for the email sending to complete.                                          //
        this.unblock();                                                                                // 34
                                                                                                       //
        _email.Email.send({                                                                            // 49
          to: to,                                                                                      // 50
          from: 'Techie Pulse <noreply@techiepulse.com>',                                              // 51
          subject: "Newsletter Sign Up",                                                               // 52
          html: SSR.render('htmlEmail', emailData)                                                     // 53
        });                                                                                            //
                                                                                                       //
        _email.Email.send({                                                                            // 56
          to: "vivek@dhutia.com",                                                                      // 57
          from: to,                                                                                    // 58
          subject: "New Subscriber",                                                                   // 59
          text: "New Subscriber: " + to                                                                // 60
        });                                                                                            //
      }                                                                                                //
                                                                                                       //
      return sendEmail;                                                                                //
    }(),                                                                                               //
                                                                                                       //
    sendEmail2: function () {                                                                          // 64
      function sendEmail2(to, text) {                                                                  // 64
        (0, _check.check)([to, text], [String]);                                                       // 65
                                                                                                       //
        SSR.compileTemplate('htmlEmail', Assets.getText('html-email.html'));                           // 67
                                                                                                       //
        var emailData = {                                                                              // 69
          name: "Vivek",                                                                               // 70
          favoriteRestaurant: "Honker Burger",                                                         // 71
          bestFriend: "Skeeter Valentine"                                                              // 72
        };                                                                                             //
                                                                                                       //
        // Let other method calls from the same client start running,                                  //
        // without waiting for the email sending to complete.                                          //
        this.unblock();                                                                                // 64
                                                                                                       //
        _email.Email.send({                                                                            // 79
          to: to,                                                                                      // 80
          from: 'Techie Pulse <noreply@techiepulse.com>',                                              // 81
          subject: "Techie Pulse Newsletter Sign Up",                                                  // 82
          html: SSR.render('htmlEmail', emailData)                                                     // 83
        });                                                                                            //
      }                                                                                                //
                                                                                                       //
      return sendEmail2;                                                                               //
    }(),                                                                                               //
                                                                                                       //
    sendMessage: function () {                                                                         // 88
      function sendMessage(name, email, subject, message) {                                            // 88
        // Let other method calls from the same client start running,                                  //
        // without waiting for the email sending to complete.                                          //
        this.unblock();                                                                                // 91
                                                                                                       //
        _email.Email.send({                                                                            // 93
          to: "info@techiepulse.com",                                                                  // 94
          from: email,                                                                                 // 95
          subject: subject + " - " + name,                                                             // 96
          text: message                                                                                // 97
        });                                                                                            //
      }                                                                                                //
                                                                                                       //
      return sendMessage;                                                                              //
    }()                                                                                                //
  });                                                                                                  //
}                                                                                                      //
                                                                                                       //
_meteor.Meteor.methods({                                                                               // 103
  'tasks.insert': function () {                                                                        // 104
    function tasksInsert(text) {                                                                       //
      (0, _check.check)(text, String);                                                                 // 105
                                                                                                       //
      // Make sure the user is logged in before inserting a task                                       //
      if (!this.userId) {                                                                              // 104
        throw new _meteor.Meteor.Error('not-authorized');                                              // 109
      }                                                                                                //
                                                                                                       //
      Tasks.insert({                                                                                   // 112
        text: text,                                                                                    // 113
        createdAt: new Date(),                                                                         // 114
        owner: this.userId,                                                                            // 115
        username: _meteor.Meteor.users.findOne(this.userId).username                                   // 116
      });                                                                                              //
    }                                                                                                  //
                                                                                                       //
    return tasksInsert;                                                                                //
  }(),                                                                                                 //
  'tasks.remove': function () {                                                                        // 119
    function tasksRemove(taskId) {                                                                     //
      (0, _check.check)(taskId, String);                                                               // 120
                                                                                                       //
      var task = Tasks.findOne(taskId);                                                                // 122
      if (task['private'] && task.owner !== this.userId) {                                             // 123
        // If the task is private, make sure only the owner can delete it                              //
        throw new _meteor.Meteor.Error('not-authorized');                                              // 125
      }                                                                                                //
                                                                                                       //
      Tasks.remove(taskId);                                                                            // 128
    }                                                                                                  //
                                                                                                       //
    return tasksRemove;                                                                                //
  }(),                                                                                                 //
  'tasks.setChecked': function () {                                                                    // 130
    function tasksSetChecked(taskId, setChecked) {                                                     //
      (0, _check.check)(taskId, String);                                                               // 131
      (0, _check.check)(setChecked, Boolean);                                                          // 132
                                                                                                       //
      var task = Tasks.findOne(taskId);                                                                // 134
      if (task['private'] && task.owner !== this.userId) {                                             // 135
        // If the task is private, make sure only the owner can check it off                           //
        throw new _meteor.Meteor.Error('not-authorized');                                              // 137
      }                                                                                                //
                                                                                                       //
      Tasks.update(taskId, { $set: { checked: setChecked } });                                         // 140
    }                                                                                                  //
                                                                                                       //
    return tasksSetChecked;                                                                            //
  }(),                                                                                                 //
  'tasks.setPrivate': function () {                                                                    // 142
    function tasksSetPrivate(taskId, setToPrivate) {                                                   //
      (0, _check.check)(taskId, String);                                                               // 143
      (0, _check.check)(setToPrivate, Boolean);                                                        // 144
                                                                                                       //
      var task = Tasks.findOne(taskId);                                                                // 146
                                                                                                       //
      // Make sure only the task owner can make a task private                                         //
      if (task.owner !== this.userId) {                                                                // 142
        throw new _meteor.Meteor.Error('not-authorized');                                              // 150
      }                                                                                                //
                                                                                                       //
      Tasks.update(taskId, { $set: { 'private': setToPrivate } });                                     // 153
    }                                                                                                  //
                                                                                                       //
    return tasksSetPrivate;                                                                            //
  }()                                                                                                  //
});                                                                                                    //
/////////////////////////////////////////////////////////////////////////////////////////////////////////

}]}},"server":{"main.js":["../imports/api/tasks.js",function(require){

/////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                     //
// server/main.js                                                                                      //
//                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                       //
require('../imports/api/tasks.js');                                                                    // 1
                                                                                                       //
Accounts.config({                                                                                      // 3
    forbidClientAccountCreation: true                                                                  // 4
});                                                                                                    //
/////////////////////////////////////////////////////////////////////////////////////////////////////////

}]}},{"extensions":[".js",".json",".jsx"]});
require("./server/main.js");
//# sourceMappingURL=app.js.map
