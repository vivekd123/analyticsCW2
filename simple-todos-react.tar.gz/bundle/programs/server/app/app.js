var require = meteorInstall({"imports":{"api":{"tasks.js":["meteor/meteor","meteor/mongo","meteor/check","meteor/email",function(require,exports){

/////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                     //
// imports/api/tasks.js                                                                                //
//                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                       //
exports.__esModule = true;                                                                             //
exports.Tasks = undefined;                                                                             //
                                                                                                       //
var _meteor = require('meteor/meteor');                                                                // 1
                                                                                                       //
var _mongo = require('meteor/mongo');                                                                  // 2
                                                                                                       //
var _check = require('meteor/check');                                                                  // 3
                                                                                                       //
var _email = require('meteor/email');                                                                  // 5
                                                                                                       //
var Tasks = exports.Tasks = new _mongo.Mongo.Collection('tasks');                                      // 6
                                                                                                       //
if (_meteor.Meteor.isServer) {                                                                         // 8
  // This code only runs on the server                                                                 //
  // Only publish tasks that are public or belong to the current user                                  //
  _meteor.Meteor.publish('tasks', function () {                                                        // 11
    function tasksPublication() {                                                                      // 11
      return Tasks.find({                                                                              // 12
        $or: [{ 'private': { $ne: true } }, { owner: this.userId }]                                    // 13
      });                                                                                              //
    }                                                                                                  //
                                                                                                       //
    return tasksPublication;                                                                           //
  }());                                                                                                //
                                                                                                       //
  _meteor.Meteor.startup(function () {                                                                 // 20
    process.env.MAIL_URL = "smtp://noreply@techiepulse.com:micron123@server511.webhostingpad.com:465";
    //                                                                                                 //
    //      Email.send({                                                                               //
    //         to: "vdhutia18@gmail.com",                                                              //
    //         from: "noreply@booking.thaiembassyuk.org.uk",                                           //
    //         subject: "Royal Thai Embassy Booking Confirmation",                                     //
    //         text: "The email content..."                                                            //
    //      });                                                                                        //
    //                                                                                                 //
  });                                                                                                  // 20
                                                                                                       //
  _meteor.Meteor.methods({                                                                             // 32
    sendEmail: function () {                                                                           // 33
      function sendEmail(to, text) {                                                                   // 33
        (0, _check.check)([to, text], [String]);                                                       // 34
                                                                                                       //
        // Let other method calls from the same client start running,                                  //
        // without waiting for the email sending to complete.                                          //
        this.unblock();                                                                                // 33
                                                                                                       //
        _email.Email.send({                                                                            // 40
          to: "vivek@dhutia.com",                                                                      // 41
          from: "v@vivekdhutia.com",                                                                   // 42
          subject: "Royal Thai Embassy Booking Confirmation",                                          // 43
          text: "text"                                                                                 // 44
        });                                                                                            //
      }                                                                                                //
                                                                                                       //
      return sendEmail;                                                                                //
    }()                                                                                                //
  });                                                                                                  //
}                                                                                                      //
                                                                                                       //
_meteor.Meteor.methods({                                                                               // 50
  'tasks.insert': function () {                                                                        // 51
    function tasksInsert(text) {                                                                       //
      (0, _check.check)(text, String);                                                                 // 52
                                                                                                       //
      // Make sure the user is logged in before inserting a task                                       //
      if (!this.userId) {                                                                              // 51
        throw new _meteor.Meteor.Error('not-authorized');                                              // 56
      }                                                                                                //
                                                                                                       //
      Tasks.insert({                                                                                   // 59
        text: text,                                                                                    // 60
        createdAt: new Date(),                                                                         // 61
        owner: this.userId,                                                                            // 62
        username: _meteor.Meteor.users.findOne(this.userId).username                                   // 63
      });                                                                                              //
    }                                                                                                  //
                                                                                                       //
    return tasksInsert;                                                                                //
  }(),                                                                                                 //
  'tasks.remove': function () {                                                                        // 66
    function tasksRemove(taskId) {                                                                     //
      (0, _check.check)(taskId, String);                                                               // 67
                                                                                                       //
      var task = Tasks.findOne(taskId);                                                                // 69
      if (task['private'] && task.owner !== this.userId) {                                             // 70
        // If the task is private, make sure only the owner can delete it                              //
        throw new _meteor.Meteor.Error('not-authorized');                                              // 72
      }                                                                                                //
                                                                                                       //
      Tasks.remove(taskId);                                                                            // 75
    }                                                                                                  //
                                                                                                       //
    return tasksRemove;                                                                                //
  }(),                                                                                                 //
  'tasks.setChecked': function () {                                                                    // 77
    function tasksSetChecked(taskId, setChecked) {                                                     //
      (0, _check.check)(taskId, String);                                                               // 78
      (0, _check.check)(setChecked, Boolean);                                                          // 79
                                                                                                       //
      var task = Tasks.findOne(taskId);                                                                // 81
      if (task['private'] && task.owner !== this.userId) {                                             // 82
        // If the task is private, make sure only the owner can check it off                           //
        throw new _meteor.Meteor.Error('not-authorized');                                              // 84
      }                                                                                                //
                                                                                                       //
      Tasks.update(taskId, { $set: { checked: setChecked } });                                         // 87
    }                                                                                                  //
                                                                                                       //
    return tasksSetChecked;                                                                            //
  }(),                                                                                                 //
  'tasks.setPrivate': function () {                                                                    // 89
    function tasksSetPrivate(taskId, setToPrivate) {                                                   //
      (0, _check.check)(taskId, String);                                                               // 90
      (0, _check.check)(setToPrivate, Boolean);                                                        // 91
                                                                                                       //
      var task = Tasks.findOne(taskId);                                                                // 93
                                                                                                       //
      // Make sure only the task owner can make a task private                                         //
      if (task.owner !== this.userId) {                                                                // 89
        throw new _meteor.Meteor.Error('not-authorized');                                              // 97
      }                                                                                                //
                                                                                                       //
      Tasks.update(taskId, { $set: { 'private': setToPrivate } });                                     // 100
    }                                                                                                  //
                                                                                                       //
    return tasksSetPrivate;                                                                            //
  }()                                                                                                  //
});                                                                                                    //
/////////////////////////////////////////////////////////////////////////////////////////////////////////

}]}},"server":{"main.js":["../imports/api/tasks.js",function(require){

/////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                     //
// server/main.js                                                                                      //
//                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                       //
require('../imports/api/tasks.js');                                                                    // 1
                                                                                                       //
Accounts.config({                                                                                      // 3
    forbidClientAccountCreation: true                                                                  // 4
});                                                                                                    //
/////////////////////////////////////////////////////////////////////////////////////////////////////////

}]}},{"extensions":[".js",".json",".jsx"]});
require("./server/main.js");
//# sourceMappingURL=app.js.map
